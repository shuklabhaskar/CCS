@extends('base_layout')

@section('content')

    <main class="content">
        <div class="container-fluid p-0">

            <h1 class="h3 mb-3"><strong>STATION</strong> INVENTORY</h1>

            <div class="container">
                <div class="row mt-3">
                    <div class="col-md-6">
                        <div class="form">
                            <i class="align-middle me-2" data-feather="search"></i>
                            <label>

                                <input type="text" class="form-control form-input"
                                       placeholder="Search anything...">
                            </label>
                        </div>
                    </div>

                    <div class="col-6 ">
                        <a href="{{url('station/create')}}" class="btn btn-primary flex-row text-end"><i
                                class="align-middle "
                                data-feather="plus"></i>&nbsp;Create
                            Station</a>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-12 ">
                    <div class="card flex-fill">
                        <div class="card-header">

                            <h5 class="card-title mb-0">STATIONS LIST</h5>
                        </div>
                        <div class="container-fluid">
                            <table class="table table-hover" id="station_table">
                                <thead>
                                <tr>
                                    <th>STATION ID</th>
                                    <th class="d-none d-xl-table-cell">STATION NAME</th>
                                    <th class="d-none d-xl-table-cell">COMPANY NAME</th>
                                    <th class="d-none d-xl-table-cell">LINE NAME</th>
                                    <th class="d-none d-xl-table-cell">STATUS</th>
                                    <th class="d-none d-md-table-cell">ACTION</th>
                                </tr>
                                </thead>
                                <tbody>


                                @foreach($stations as $station)
                                    <tr>

                                        <td>{{$station->station_id}}</td>
                                        <td class="d-none d-xl-table-cell">{{$station->station_name}}</td>
                                        <td class="d-none d-xl-table-cell">{{$station->company_name}}</td>
                                        <td class="d-none d-xl-table-cell">{{$station->line_name}}</td>
                                        @if($station -> status == "1")
                                            <td><span class="badge bg-success">ACTIVE</span></td>
                                        @elseif($station -> status == "0")
                                            <td><span class="badge bg-danger">INACTIVE</span></td>
                                        @endif

                                        <td class="d-none d-md-table-cell">
                                            <a href="{{('station/update/'.$station->station_id)}}"><span
                                                    class="badge bg-danger"><i class="align-middle "
                                                                               data-feather="edit-2"></i></span></a>

                                        </td>
                                    </tr>
                                @endforeach


                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>


        </div>
    </main>


    <script>
        $(document).ready( function () {
            $('#station_table').DataTable();
        } );
    </script>

@endsection
