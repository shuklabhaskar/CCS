<?php

use App\Http\Controllers\EquipController;
use App\Http\Controllers\index;
use App\Http\Controllers\StationController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[index::class,'show']);

Route::get('station', [StationController::class, 'getStations']);
Route::get('station/create', [StationController::class, 'createStationView']);
Route::get('station/update/{id}', [StationController::class, 'updateStationView']);


Route::post('station/create', [StationController::class, 'createStation']);
Route::post('station/update/{id}', [StationController::class, 'updateStation']);



Route::get('equipment/{id}',[EquipController::class,'getEquip']);
Route::get('equip/create',[EquipController::class,'createEquip']);
