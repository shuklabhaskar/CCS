<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="col-12 col-md-12 ">
            <div class="card flex-fill">
                <div class="card-header">

                    <h5 class="card-title mb-0"><?php echo e($title); ?> EQUIPMENTS</h5>

                    <div class="container">
                        <div class="row mt-3">

                            <div class="col-12">
                                <a href="<?php echo e(url('equip/create')); ?>" class="btn btn-primary pull-right"><i
                                        class="fa fa-plus-square"></i>&nbsp; CREATE EQUIPMENTS</a>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="container-fluid">
                    <table class="table  table-hover" id="equip_table">
                        <thead>
                        <tr>
                            <th class="d-none d-xl-table-cell">EQUIP ID</th>

                            <th class="d-none d-xl-table-cell">WORKING MODE</th>

                            <th class="d-none d-md-table-cell">IP ADDRESS</th>
                            <th class="d-none d-md-table-cell">STATION</th>
                            <th class="d-none d-md-table-cell">STATUS</th>
                            <th class="d-none d-md-table-cell">END DATE</th>
                            <th class="d-none d-md-table-cell">ACTION</th>
                        </tr>
                        </thead>

                        <tbody>

                        <?php $__currentLoopData = $eqData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($data -> equipment_id); ?></td>

                                <?php if($data->eq_mode_id == "1"): ?>
                                    <td class="d-none d-xl-table-cell">ENTRY</td>
                                <?php elseif($data->eq_mode_id == "3"): ?>
                                    <td class="d-none d-xl-table-cell">BI-DI</td>
                                <?php else: ?>
                                    <td class="d-none d-xl-table-cell">EXIT</td>
                                <?php endif; ?>

                                <td class="d-none d-xl-table-cell"><?php echo e($data -> ip_address); ?></td>
                                <td class="d-none d-xl-table-cell"><?php echo e($data -> station_name); ?></td>

                                <?php if($data->status == "1"): ?>
                                    <td class="d-none d-md-table-cell"><span
                                            class="badge bg-success">ACTIVE</span></td>
                                <?php else: ?>
                                    <td class="d-none d-md-table-cell"><span
                                            class="badge bg-danger">INACTIVE</span></td>
                                <?php endif; ?>

                                <td class="d-none d-md-table-cell"><?php echo e($data -> end_date); ?></td>
                                <td class="d-none d-md-table-cell">
                                    <a href=" <?php echo e(url("eq/edit/".$data -> equipment_id)); ?> "><span
                                            class="badge bg-danger"><i
                                                class="align-middle " data-feather="edit-2"></i></span></a>

                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>

            </div>
        </div>
    </main>

    <script>
        $(document).ready(function () {
            $('#equip_table').DataTable();
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushm\OneDrive\Desktop\BAHSKAR CONFIDENTIAL\resources\views/EQUIPMENTS/equipments.blade.php ENDPATH**/ ?>