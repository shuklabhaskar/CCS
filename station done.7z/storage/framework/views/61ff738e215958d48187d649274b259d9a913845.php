<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="col-12 col-md-12 ">
            <div class="card flex-fill">
                <div class="card-header">

                    <?php if(!empty($data)): ?>
                        <h5>EDIT EQUIPMENTS</h5>

                        <form method="post" action="<?php echo e(url('eq/update/'.$data-> equipment_id)); ?>">

                            <?php echo csrf_field(); ?>

                            <div class="row mt-4">

                                <div class="col-md-3">
                                    <label for="equipment_id"></label>
                                    <input class="form-control" name="equipment_id"
                                           type="text" id="equipment_id" disabled value="<?php echo e($data -> equipment_id); ?>">
                                    <br>
                                </div>
                                <div class="col-md-3">

                                    <label class="w-100">Equipment_type
                                        <select class="form-select mb-3" name="equipment_type">
                                            <option selected>equipment_type</option>
                                            <?php if($data->eq_type_id == "1"): ?>
                                                <option selected value="1">AG</option>
                                            <?php else: ?>
                                                <option value="1">AG</option>
                                            <?php endif; ?>

                                            <?php if($data->eq_type_id =="2"): ?>
                                                <option selected value="2">POST</option>
                                            <?php else: ?>
                                                <option value="2">POST</option>
                                            <?php endif; ?>
                                        </select>
                                    </label>

                                </div>

                                <div class="col-md-3">
                                    <label class="w-100">Line
                                        <select class="form-select mb-3" name="line">
                                            <option selected>Select line</option>
                                            <?php $__currentLoopData = $L_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ldata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($ldata -> line_id == $data -> line_id ): ?>`
                                                    <option selected
                                                            value="<?php echo e($ldata -> line_id); ?>"><?php echo e($ldata -> line_name); ?></option>
                                                <?php else: ?>
                                                    <option
                                                        value="<?php echo e($ldata -> line_id); ?>"><?php echo e($ldata -> line_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </label>

                                </div>


                                <div class="col-md-3">

                                    <label class="w-100">Company
                                        <select class="form-select mb-3" name="Company_Name">
                                            <option>Select Company</option>

                                            <?php $__currentLoopData = $C_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($cdata -> company_id == $data -> company_id): ?>
                                                    <option selected
                                                            value="<?php echo e($cdata -> company_id); ?>"><?php echo e($cdata -> company_name); ?></option>
                                                <?php else: ?>
                                                    <option
                                                        value="<?php echo e($cdata -> company_id); ?>"><?php echo e($cdata -> company_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </label>

                                </div>


                            </div>

                            <div class="row mt-2">
                                <div class="col-md-3">
                                    <label class="w-100">Station
                                        <select class="form-select mb-3" name="station_id">
                                            <?php $__currentLoopData = $Stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($data->station_id == $station->station_id): ?>
                                                    <option selected
                                                            value="<?php echo e($station->station_id); ?>"><?php echo e($station->station_name); ?></option>
                                                <?php else: ?>
                                                    <option
                                                        value="<?php echo e($station->station_id); ?>"><?php echo e($station->station_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </select>
                                    </label>


                                </div>
                                <div class="col-md-3">

                                    <label class="w-100">Status
                                        <select class="form-select mb-3" name="status">
                                            <option>Select Status</option>
                                            <?php if($data->status == "1"): ?>
                                                <option selected value="1">ACTIVE</option>
                                            <?php else: ?>
                                                <option value="1">ACTIVE</option>
                                            <?php endif; ?>

                                            <?php if($data->status == "0"): ?>
                                                <option selected value="0">INACTIVE</option>
                                            <?php else: ?>
                                                <option value="0">INACTIVE</option>
                                            <?php endif; ?>
                                        </select>
                                    </label>

                                </div>

                                <div class="col-md-3">
                                    <label for="description">Description</label>
                                    <input class="form-control" name="description" type="text" id="description"
                                           value="<?php echo e($data->description); ?>">
                                    <br>
                                </div>

                                <div class="col-md-3">

                                    <label class="w-100">Equipment Mode
                                        <select class="form-select mb-3" name="working_type_id">

                                            <?php if($data->eq_working_mode_id =="0"): ?>
                                                <option selected value="0">ENTRY</option>
                                            <?php else: ?>
                                                <option value="0">ENTRY</option>
                                            <?php endif; ?>

                                            <?php if($data->eq_working_mode_id =="1"): ?>
                                                <option selected value="1">EXIT</option>
                                            <?php else: ?>
                                                <option value="1">EXIT</option>
                                            <?php endif; ?>

                                            <?php if($data->eq_working_mode_id =="3"): ?>
                                                <option selected value="3">BI-DI</option>
                                            <?php else: ?>
                                                <option value="3">BI-DI</option>
                                            <?php endif; ?>


                                        </select>
                                    </label>

                                </div>
                                `
                            </div>
                            <div class="row mt-2">

                                <div class="col-md-3">
                                    <label for="ip">Ip address</label>
                                    <input class="form-control" name="ip" type="text" id="ip"
                                           value="<?php echo e($data->ip_address); ?>">
                                    <br>
                                </div>
                                <div class="col-md-3">
                                    <label for="end_date">End date</label>
                                    <input class="form-control" name="end_date" type="text" id="end_date"
                                           value="<?php echo e($data->end_date); ?>">
                                    <br>
                                </div>
                                <div class="col-md-3">
                                    <label for="key_hash">End point key hash</label>
                                    <input class="form-control" name="key_hash" type="text" id="key_hash"
                                           value="<?php echo e($data->endpointKeyHash); ?>">
                                    <br>
                                </div>
                                <div class="col-md-3">
                                    <label for="gate_id">Gate id </label>
                                    <input class="form-control" name="gate_id" type="text" id="gate_id"
                                           value="<?php echo e($data->gateId); ?>">
                                    <br>
                                </div>

                            </div>
                            <div class="row mt-2">


                                <div class="col-md-3">
                                    <label for="host_name">Host name</label>
                                    <input class="form-control" name="host_name" type="text" id="host_name"
                                           value="<?php echo e($data->hostName); ?>">
                                    <br>
                                </div>

                                <div class="col-md-3">
                                    <label for="primary_ssid">primary ssid</label>
                                    <input class="form-control" name="primary_ssid" type="text" id="primary_ssid"
                                           value="<?php echo e($data->primarySSID); ?>">
                                    <br>
                                </div>

                                <div class="col-md-3">
                                    <label for="ssid_password">primary password</label>
                                    <input class="form-control" name="ssid_password" type="text" id="ssid_password"
                                           value="<?php echo e($data->primarySSIDPassword); ?>">
                                    <br>
                                </div>

                                <div class="col-md-3">
                                    <label for="backup_ssid">Backup ssid</label>
                                    <input class="form-control" name="backup_ssid" type="text" id="backup_ssid"
                                           value="<?php echo e($data->backupSSID); ?>">
                                    <br>
                                </div>

                            </div>
                            <div class="row mt-2">

                                <div class="col-md-3">
                                    <label for="backup_password">Backup ssid password</label>
                                    <input class="form-control" name="backup_password" type="text" id="backup_password"
                                           value="<?php echo e($data->backupSSIDPassword); ?>">
                                    <br>
                                </div>
                                <div class="col-md-3">
                                    <label for="gate_way">Gate way</label>
                                    <input class="form-control" name="gate_way" type="text" id="gate_way"
                                           value="<?php echo e($data->gateway); ?>">
                                    <br>
                                </div>
                                <div class="col-md-3">
                                    <label for="Subnet_Mask">Subnet Mask</label>
                                    <input class="form-control" name="Subnet_Mask" type="text" id="Subnet_Mask"
                                           value="<?php echo e($data->subnet_mask); ?>">
                                    <br>
                                </div>

                                <div class="col-md-3">
                                    <label for="CCHS">CCHS reference</label>
                                    <input class="form-control" name="CCHS" type="text" id="CCHS"
                                           value="<?php echo e($data->cchs_reference); ?>">
                                    <br>
                                </div>

                            </div>
                            <div class="row mt-2">

                                <div class="col-md-3">

                                    <label class="w-100">CCHS station
                                        <select class="form-select mb-3" name="cchs_station_id">
                                            <?php $__currentLoopData = $Stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($data->station_id == $station->station_id): ?>
                                                    <option selected
                                                            value="<?php echo e($station->station_id); ?>"><?php echo e($station->station_name); ?></option>
                                                <?php else: ?>
                                                    <option
                                                        value="<?php echo e($station->station_id); ?>"><?php echo e($station->station_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </label>

                                </div>
                                <div class="col-md-3">
                                    <label for="Coor_X">Coor-X</label>
                                    <input class="form-control" name="Coor_X" type="text" id="Coor_X"
                                           value="<?php echo e($data->coord_x); ?>">
                                    <br>
                                </div>
                                <div class="col-md-3">
                                    <label for="Coor_Y">Coor-Y</label>
                                    <input class="form-control" name="Coor_Y" type="text" id="Coor_Y"
                                           value="<?php echo e($data->coord_y); ?>">
                                    <br>
                                </div>

                            </div>

                            <div class="row">

                                <div class="col w-100">
                                    <a href="<?php echo e(url('equipment/'.$data-> eq_type_id)); ?>"
                                       class="btn btn-primary bg-dark btn-outline-dark"><i class="align-middle "
                                                                                           data-feather="skip-back"></i>&nbsp;BACK</a>
                                    <button class="btn btn-primary"><i class="align-middle "
                                                                       data-feather="user-plus"></i>&nbsp;UPDATE
                                        EQUIPMENT
                                    </button>
                                </div>

                            </div>
                        </form>

                    <?php else: ?>
                        <h5 class="card-title mb-0">CREATE EQUIPMENTS</h5>
                        <form method="post" action="<?php echo e(url('eq/create')); ?>">

                            <?php echo csrf_field(); ?>

                            <div class="row mt-4">

                                <div class="col-md-3">
                                    <label for="station_name">Atek id<span class="text-danger"> *</span></label>
                                    <input class="form-control" required="" name="equipment_id"
                                           type="text" id="station_name">
                                    <br>
                                </div>
                                
                                <div class="col-md-3">
                                    <label for="station_name">Equipment id<span class="text-danger"> *</span></label>
                                    <input class="form-control" required="" name="equipment_id"
                                           type="text" id="station_name">
                                    <br>
                                </div>
                                <div class="col-md-3">

                                    <label class="w-100">Equipment_type<span class="text-danger"> *</span>
                                        <select class="form-select mb-3" name="equipment_type">
                                            <option selected>Select_type</option>
                                            <option value="1">AG</option>
                                            <option value="2">POST</option>
                                        </select>
                                    </label>

                                </div>

                                <div class="col-md-3">
                                    <label class="w-100">Line<span class="text-danger"> *</span>
                                        <select class="form-select mb-3" name="line">
                                            <option selected>Select line</option>
                                            <?php $__currentLoopData = $L_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($l_data->line_id); ?>"><?php echo e($l_data->line_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </label>

                                </div>


                                <div class="col-md-3">

                                    <label class="w-100">Company<span class="text-danger"> *</span>
                                        <select class="form-select mb-3" name="Company_Name">
                                            <option selected>Select Company</option>
                                            <?php $__currentLoopData = $Company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $companies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value=""><?php echo e($companies->company_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </label>

                                </div>


                            </div>

                            <div class="row mt-2">
                                <div class="col-md-3">
                                    <label class="w-100">Station<span class="text-danger"> *</span>
                                        <select class="form-select mb-3" name="station_id">
                                            <option selected>Select Station</option>
                                            <?php $__currentLoopData = $Stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($station->station_id); ?>"><?php echo e($station->station_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </label>


                                </div>
                                <div class="col-md-3">

                                    <label class="w-100">Status<span class="text-danger"> *</span>
                                        <select class="form-select mb-3" name="status">
                                            <option selected>Select Status</option>
                                            <option value="1">ACTIVE</option>
                                            <option value="0">INACTIVE</option>
                                        </select>
                                    </label>
                                </div>

                                <div class="col-md-3">
                                    <label for="description">Description<span class="text-danger"> *</span></label>
                                    <input class="form-control" required="" name="description"
                                           type="text" id="description">
                                    <br>
                                </div>

                                <div class="col-md-3">

                                    <label class="w-100">Working type<span class="text-danger"> *</span>
                                        <select class="form-select mb-3" name="working_type_id">
                                            <option selected>Select type</option>
                                            <option value="0">ENTRY</option>
                                            <option value="1">EXIT</option>
                                            <option value="3">BI-DI</option>


                                        </select>
                                    </label>

                                </div>

                            </div>
                            <div class="row mt-2">

                                <div class="col-md-3">
                                    <label for="ip">Ip address<span class="text-danger"> *</span></label>
                                    <input class="form-control" required="" name="ip"
                                           type="text" id="ip">
                                    <br>
                                </div>
                                <div class="col-md-3">
                                    <label for="end_date">End date</label>
                                    <input class="form-control" name="end_date"
                                           type="text" id="end_date">
                                    <br>
                                </div>
                                <div class="col-md-3">
                                    <label for="key_hash">End point key hash</label>
                                    <input class="form-control" name="key_hash"
                                           type="text" id="key_hash">
                                    <br>
                                </div>
                                <div class="col-md-3">
                                    <label for="gate_id">Gate id <span class="text-danger"> *</span></label>
                                    <input class="form-control" required="" name="gate_id"
                                           type="text" id="gate_id">
                                    <br>
                                </div>

                            </div>
                            <div class="row mt-2">


                                <div class="col-md-3">
                                    <label for="host_name">Host name</label>
                                    <input class="form-control" name="host_name"
                                           type="text" id="host_name">
                                    <br>
                                </div>

                                <div class="col-md-3">
                                    <label for="primary_ssid">Ap primary ssid<span class="text-danger"> *</span></label>
                                    <input class="form-control" name="primary_ssid"
                                           type="text" id="primary_ssid">
                                    <br>
                                </div>

                                <div class="col-md-3">
                                    <label for="ssid_password">Ap primary password<span
                                            class="text-danger"> *</span></label>
                                    <input class="form-control" required="" name="ssid_password"
                                           type="text" id="ssid_password">
                                    <br>
                                </div>

                                <div class="col-md-3">
                                    <label for="backup_ssid">Backup ssid</label>
                                    <input class="form-control" name="backup_ssid"
                                           type="text" id="backup_ssid">
                                    <br>
                                </div>

                            </div>
                            <div class="row mt-2">

                                <div class="col-md-3">
                                    <label for="backup_password">Backup ssid password</label>
                                    <input class="form-control" name="backup_password"
                                           type="text" id="backup_password">
                                    <br>
                                </div>
                                <div class="col-md-3">
                                    <label for="gate_way">Gate way<span class="text-danger"> *</span></label>
                                    <input class="form-control" required="" name="gate_way"
                                           type="text" id="gate_way">
                                    <br>
                                </div>
                                <div class="col-md-3">
                                    <label for="Subnet_Mask">Subnet Mask<span class="text-danger"> *</span></label>
                                    <input class="form-control" required="" name="Subnet_Mask"
                                           type="text" id="Subnet_Mask">
                                    <br>
                                </div>

                                <div class="col-md-3">
                                    <label for="CCHS">CCHS reference</label>
                                    <input class="form-control" name="CCHS"
                                           type="text" id="CCHS">
                                    <br>
                                </div>

                            </div>
                            <div class="row mt-2">

                                <div class="col-md-3">

                                    <label class="w-100">CCHS station
                                        <select class="form-select mb-3" name="cchs_station_id">
                                            <option selected>Select Station</option>
                                            <option value="1">ghatkopar</option>
                                        </select>
                                    </label>

                                </div>
                                <div class="col-md-3">
                                    <label for="Coor_X">Coor-X</label>
                                    <input class="form-control" name="Coor_X"
                                           type="text" id="Coor_X">
                                    <br>
                                </div>
                                <div class="col-md-3">
                                    <label for="Coor_Y">Coor-Y</label>
                                    <input class="form-control" name="Coor_Y"
                                           type="text" id="Coor_Y">
                                    <br>
                                </div>

                            </div>

                            <div class="row">

                                <div class="col w-100">
                                    <a href="<?php echo e(url('equipment/{name}')); ?>"
                                       class="btn btn-primary bg-dark btn-outline-dark"><i class="align-middle "
                                                                                           data-feather="skip-back"></i>&nbsp;Back</a>
                                    <button class="btn btn-primary"><i class="align-middle "
                                                                       data-feather="user-plus"></i>&nbsp;CREATE
                                        EQUIPMENT
                                    </button>
                                </div>

                            </div>
                        </form>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushm\OneDrive\Desktop\BAHSKAR CONFIDENTIAL\resources\views/EQUIPMENTS/editequip.blade.php ENDPATH**/ ?>