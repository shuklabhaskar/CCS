<?php $__env->startSection('content'); ?>


    <main class="content">
        <div class="container-fluid p-0">

            <div class="card flex-fill">
                <div class="card-header">



                    <?php if(!empty($station)): ?>
                        <h5 class="card-title mb-0">EDIT STATION * *</h5>
                        <form method="post" action="<?php echo e(url('station/update/'.$station -> station_id)); ?>">

                            <?php echo csrf_field(); ?>

                            <div class="row" style="margin-top: 40px">

                                <div class="col-md-4">
                                    <label for="station_name">Station Id</label>
                                    <input disabled class="form-control" required="" name="station_id"
                                            type="text" id="station_name" value="<?php echo e($station -> station_id); ?>">
                                    <br>
                                </div>
                                <div class="col-md-4">
                                    <label for="station_name">Station Name</label>
                                    <input class="form-control" required="" name="station_name"
                                           type="text" id="station_name" value="<?php echo e($station -> station_name); ?>">
                                    <br>
                                </div>
                                <div class="col-md-4">
                                    <label for="Description">Description</label>
                                    <input class="form-control" required="" name="description"
                                           type="text" id="station_name" value="<?php echo e($station -> description); ?>">
                                    <br>
                                </div>

                            </div>

                            <div class="row" style="margin-top: 10px">

                                <div class="col-md-4">

                                    <label class="w-100">Company
                                        <select class="form-select mb-3" name="company_id">
                                            <option>Select Company</option>

                                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($cdata -> company_id == $station -> company_id): ?>
                                                    <option selected value="<?php echo e($cdata -> company_id); ?>"><?php echo e($cdata -> company_name); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($cdata -> company_id); ?>"><?php echo e($cdata -> company_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </label>

                                </div>
                                <div class="col-md-4">

                                    <label class="w-100">Status<span class="text-danger">*</span>
                                        <select class="form-select mb-3" name="status" >
                                            <option>Select Status</option>
                                            <?php if($station->status == "1"): ?>
                                                <option selected value="1">ACTIVE</option>
                                            <?php else: ?>
                                                <option selected value="1">ACTIVE</option>
                                            <?php endif; ?>

                                            <?php if($station->status == "0"): ?>
                                                <option selected value="0">INACTIVE</option>
                                            <?php else: ?>
                                                <option value="0">INACTIVE</option>
                                            <?php endif; ?>

                                        </select>
                                    </label>

                                </div>

                                <div class="col-md-4">
                                    <label class="w-100">Line
                                        <select class="form-select mb-3" name="line_id">
                                            <option>Select Line</option>

                                            <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ldata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($ldata -> line_id == $station -> line_id ): ?>
                                                    <option selected value="<?php echo e($ldata -> line_id); ?>"><?php echo e($ldata -> line_name); ?></option>
                                                <?php else: ?>
                                                    <option  value="<?php echo e($ldata -> line_id); ?>"><?php echo e($ldata -> line_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </label>
                                </div>
                            </div>

                            <div class="row" style="margin-top: 10px">

                                <div class="col-md-4">
                                    <label for="station_name">Short Name</label>
                                    <input class="form-control" required="" name="stn_short_name"
                                           type="text" id="station_name" value="<?php echo e($station -> stn_short_name); ?>">
                                    <br>
                                </div>

                                <div class="col-md-4">
                                    <label for="station_name">Hindi Name</label>
                                    <input class="form-control" required="" name="stn_national_lang"
                                           type="text" id="station_name" value="<?php echo e($station -> stn_national_lang); ?>">
                                    <br>
                                </div>

                                <div class="col-md-4">
                                    <label for="station_name">Marathi Name </label>
                                    <input class="form-control" required="" name="stn_regional_lang"
                                           type="text" id="station_name" value="<?php echo e($station -> stn_regional_lang); ?>">
                                    <br>
                                </div>

                                <div class="row mt-3">

                                    <div class="col-md-4">
                                        <label class="w-100">Co-ord-X</label>
                                        <input class="form-control" required="" name="cord_x"
                                               type="text" id="station_name" value="<?php echo e($station -> cord_x); ?>">
                                        <br>
                                    </div>

                                    <div class="col-md-4">
                                        <label class="w-100">Co-ord-Y</label>
                                        <input class="form-control" required="" name="cord_y"
                                               type="text" id="station_name" value="<?php echo e($station -> cord_y); ?>">
                                        <br>
                                    </div>

                                </div>

                                <div class="row">

                                    <div class="col w-100">


                                        <button class="btn btn-dark"><i class="fa fa-home"></i> BACK </button>

                                        <button class="btn btn-success"><i class="fa fa-edit mx-1"></i>UPDATE STATION</button>
                                    </div>

                                </div>
                            </div>
                        </form>

                    <?php else: ?>
                        <h5 class="card-title mb-0">CREATE STATION * *</h5>
                        <form method="post" action="<?php echo e(url('station/create')); ?>">



                            <?php echo csrf_field(); ?>

                            <div class="row" style="margin-top: 40px">

                                <div class="col-md-4">
                                    <label for="station_id">Station Id<span class="text-danger"> *</span></label>
                                    <input class="form-control" required="" name="station_id" type="text" id="station_id" value="">
                                    <br>
                                </div>
                                <div class="col-md-4">
                                    <label for="station_name">Station Name<span class="text-danger"> *</span></label>
                                    <input class="form-control" required="" name="station_name"
                                           type="text" id="station_name">
                                    <br>
                                </div>
                                <div class="col-md-4">
                                    <label for="station_name">Description<span class="text-danger"> *</span></label>
                                    <input class="form-control" required="" name="description"
                                           type="text" id="station_name">
                                    <br>
                                </div>

                            </div>

                            <div class="row" style="margin-top: 10px">

                                <div class="col-md-4">

                                    <label class="w-100">Company<span class="text-danger"> *</span>
                                        <select class="form-select mb-3" name="company_name">
                                            <option selected> please Select Company</option>
                                            <option value="1">MMOPL</option>
                                        </select>
                                    </label>

                                </div>
                                <div class="col-md-4">

                                    <label class="w-100">Status<span class="text-danger"> *</span>
                                        <select class="form-select mb-3" name="status">
                                            <option selected>Select Status</option>
                                            <option value="1">ACTIVE</option>
                                            <option value="0">INACTIVE</option>
                                        </select>
                                    </label>

                                </div>

                                <div class="col-md-4">
                                    <label class="w-100">Line<span class="text-danger"> *</span>
                                        <select class="form-select mb-3" name="line_name">
                                            <option selected>Select Line</option>
                                            <option value="1">VERSOVA-GHATKOPAR</option>
                                        </select>
                                    </label>
                                </div>
                            </div>

                            <div class="row" style="margin-top: 10px">

                                <div class="col-md-4">
                                    <label for="station_name">Short Name<span class="text-danger"> *</span></label>
                                    <input class="form-control" required="" name="stn_short_name"
                                           type="text" id="station_name">
                                    <br>
                                </div>

                                <div class="col-md-4">
                                    <label for="station_name">Hindi Name<span class="text-danger"> *</span></label>
                                    <input class="form-control" required="" name="stn_national_lang"
                                           type="text" id="station_name">
                                    <br>
                                </div>

                                <div class="col-md-4">
                                    <label for="station_name">Marathi Name <span class="text-danger"> *</span> </label>
                                    <input class="form-control" required="" name="stn_regional_lang"
                                           type="text" id="station_name">
                                    <br>
                                </div>

                                <div class="row mt-3">

                                    <div class="col-md-4">
                                        <label class="w-100">Co-ord-X <span class="text-danger"> *</span></label>
                                        <input class="form-control" required="" name="cord_x"
                                               type="text" id="station_name">
                                        <br>
                                    </div>

                                    <div class="col-md-4">
                                        <label class="w-100">Co-ord-Y <span class="text-danger"> *</span></label>
                                        <input class="form-control" required="" name="cord_y"
                                               type="text" id="station_name">
                                        <br>
                                    </div>

                                </div>

                                <div class="row">

                                    <div class="col w-100">
                                        <a href="<?php echo e(url('station')); ?>"
                                           class="btn btn-primary bg-dark btn-outline-dark"><i class="align-middle "
                                                                                               data-feather="skip-back"></i>&nbsp;Back</a>
                                        <button class="btn btn-primary"><i class="align-middle "
                                                                           data-feather="user-plus"></i>&nbsp;CREATE
                                            STATION
                                        </button>
                                    </div>

                                </div>
                            </div>
                        </form>

                    <?php endif; ?>

                </div>
            </div>

        </div>
    </main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushm\OneDrive\Desktop\BAHSKAR CONFIDENTIAL\resources\views/STATION/editstation.blade.php ENDPATH**/ ?>